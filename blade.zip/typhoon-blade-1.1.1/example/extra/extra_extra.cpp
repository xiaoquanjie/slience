#include "extra_extra.h"

#include <iostream>

void ExtraExtra() {
	std::cout << "ExtraExtra" << "\n";
}
